class Rectangle
{
  static int count;
  int length, width;
  int area()
  {
     return(length*width);
  }
  void setDimensions(int l, int w)
  { 
    //System.out.println("In the Constructor of two parameter");
    length = l;
    width  = w;    
  }
  void setDimensions(int l)
  { 
    //System.out.println("In the Constructor of one parameter");
    setDimensions(l,l);
  }
  Rectangle (int l, int w)
  {
     System.out.println("In the Constructor of Two parameter");
     setDimensions(l,w);  
  } 
  Rectangle(int l)
  {
    this(l,l);     
    System.out.println("In the Constructor of one parameter");
     
  }
  protected void finalize()
  {
     count--;
  }    
  static int getcount()
  {
    return count;
  }
  {                        // Initializer block 
    count++;
    System.out.println("In initializer block"+" "+count);
  }
  static                  // class Initializer block
  {
    System.out.println("In Initializer class"); 
    count = 0; 
  }
}


class TestRectangle
{
  public static void main(String args[])
  {
    
    Rectangle r1,r2; 
    r1 = new Rectangle(7);       // Results in loading of the class, Results in the execution of Initializer
    //r2 = new Rectangle(10,6);
    int rectangleCount = Rectangle.getcount();
    System.out.println("The value of count is "+rectangleCount);
    int area = r1.area();
    System.out.println("The area of rectangle Coorespond to r1 is "+ area);
  }
}