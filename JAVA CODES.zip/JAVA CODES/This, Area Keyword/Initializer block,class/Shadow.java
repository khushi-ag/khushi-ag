class Rectangle
{
  int length, breadth;
  int area()
  {
     return(length * breadth);
  }
  Rectangle(int l, int b)
  {
     length = l;
     breadth = b;
  }
}


class Cuboid extends Rectangle
{
  int length=2;                // shadow Variable, remains zero since it is not initialized from constructor
  int height;
  int voulme()
  {
     return (area()*height); 
  }
  int area()                 // method overriding
  {
    return (length*height);
  }
  Cuboid(int l, int w, int h)
  {
     super(l,w);
     height = h;
  }
  Cuboid(int l)
  {
     this(l,l,l);
  }
}
class TestCuboid
{
  public static void main(String args[])
  {
    Rectangle r1,r2;
    Cuboid c1,c2;
    r1 = new Rectangle(7,5);
    r2 = new Cuboid(7,5,4);
    c1 = new Cuboid(7,5,4);
    System.out.println("Area of r1 :"+r1.area());    //35
    System.out.println("Area of r2 :"+r2.area());   // 35
    System.out.println("Area of c1 :"+c1.area());    //28
    System.out.println("Length of r1 :"+r1.length);
    System.out.println("Length of r2 :"+r2.length);
    System.out.println("Length of c1 :"+c1.length);  
  } 
}