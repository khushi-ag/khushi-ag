
//------------------------------------ReInitializing the Final Instance variable ----------------------------------------------------------
/*class Bike
{
  final int speedlimit = 90;
  
  void run()
  {
     speedlimit = 400;
  }
}

class Final1
{
 public static void main(String args[])
 {
    Bike b = new Bike();
    b.run();
 }
} */

//------------------------------------overriding the final method ----------------------------------------------------------

/*class Bike
{
  final void run()
  {
    System.out.println("Hello from final run");
  }
  
}

class Final1 extends Bike
{
  void run()
  {
    System.out.println("Hello from final1 run");
  }
 public static void main(String args[])
 {
     Bike b = new Bike();
     b.run();   
 }
}  */

//--------------------------------------Making the class Final-------------------------------------------------

/*final class Bike
{
  void run()
  {
    System.out.println("Hello from final run");
  }
  
}

class Final1 extends Bike
{
  void run()
  {
    System.out.println("Hello from final1 run");
  }
 public static void main(String args[])
 {
     Bike b = new Bike();
     b.run();   
 }
}*/

//----------------------------------Final Method Inherited-----------------------------------------------------


/*class Bike
{
  final void run()
  {
    System.out.println("Hello from final run");
  }
  
}

class Final1 extends Bike
{
  public static void main(String args[])
 {
     Final1 ff = new Final1();
     ff.run();   
 }
}*/

//-----------------------------------------Blank Final Variable----------------------------------------------

/*class Bike
{
  final int speedlimit;
  
  Bike()
  {
    speedlimit = 400;
  }
  void run()
  {
     System.out.println("the speedlimit is "+ speedlimit);
  }
}

class Final1
{
 public static void main(String args[])
 {
    Bike b = new Bike();
    b.run();
 }
}*/


//--------------------------------------------------------Static Blank final Variable-------------------------------


/*class Bike
{
  static final int speedlimit;
  
  static
  {
    speedlimit = 400;
  }
  void run()
  {
     System.out.println("the speedlimit is "+ speedlimit);
  }
}

class Final1
{
 public static void main(String args[])
 {
    Bike b = new Bike();
    b.run();
 }
}*/




