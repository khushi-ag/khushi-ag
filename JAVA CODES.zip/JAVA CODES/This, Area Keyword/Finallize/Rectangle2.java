class Rectangle
{
  int length, width;
  static int count;
  int area()
  {
     return(length*width);
  }
  Rectangle (int l, int w)
  {
     
     length = l;
     width  = w;
     count++;
     System.out.println("count in constructor : "+ count); 
  } 
  Rectangle(int l)
  {
     this(l,l);
  }
 protected void finalize()
  {
     count--;
     System.out.println("count in finalize : "+ count); 
  }
}

class TestRectangle
{
  public static void main(String args[])
  {
     Rectangle r1 = new Rectangle(5,7);
     System.out.println("The Result of r1.area  is" +r1.area());
     Rectangle r2 = new Rectangle(2);
     System.out.println("The Result of r2.area is" +r2.area());
     r2=r1;
     System.out.println("After changing the refrence : 0");
   System.out.println("The Resultof r1.area  is" +r1.area());
     System.out.println("The Result of r2.area  is" +r2.area()); 
     
     r2.finalize();    
     System.out.println("The Result is" +r2.area()); 
     
    
  }


}