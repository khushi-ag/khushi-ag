class FinalizeTest 
{ 
        private String name; 
 
        public FinalizeTest(String s) 
        { 
                name = s; 
  System.out.println (name); 
        } 
 
        protected void finalize() 
        { 
                System.out.println (name); 
        } 
} 
class Tests
{ 
        public static void call() 
        { 
                FinalizeTest x1 = new FinalizeTest("Java");
                   FinalizeTest  y1 = new FinalizeTest("Hello"); 
 FinalizeTest  z1 = new FinalizeTest("Hellosss"); 
        } 
 
        public static void main(String[] args)
        { 
                call(); 
                System.gc(); 
        } 
}