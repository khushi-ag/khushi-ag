class Vehicle
{
   int speed = 50;
   Vehicle()
   {
      System.out.println("Super class constructor");
   }
   void show()
   {
      System.out.println("Hello From Vehicle Class");
   }
}

class Bike extends Vehicle
{
  
  Bike()
  {
      super();
      show();
      super.show();
      System.out.println("Sub-derived  class constructor");
  }
  int speed = 100;
  
  void display()
  {
      System.out.println(super.speed);
      System.out.println(speed);
  }

  void show()
   {
      System.out.println("Hello From BikeClass");
   }
  
  public static void main(String args[])
  {
    Bike b = new Bike();
    b.display();
    b.show();
  }
}