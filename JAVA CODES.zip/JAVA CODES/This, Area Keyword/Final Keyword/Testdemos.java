// Method Returning This Refrence

class demo
{
  int num;
  demo(int num)
  {
    this.num = num;
  }
  void show()
  {
    System.out.println("num :="+this.num);
  }
  demo incr()
  {
    num++;
    return this;
  }
}

class Testdemos
{
  public static void main(String args[])
  {
    demo d1 = new demo(10);
    System.out.println("call method incr three times here ");
    d1.incr().incr().incr().show();
  }
}

/*
output:
call method incr three times here
num :=13
*/