// Final argument to Methods

class demo
{
  String str;
  demo (final String s)
  {
     str = s;
     s = "hello";
  }
}

class Tempdemo
{
  public static void main(String args[])
  {
    demo d = new demo("good morning");
  }
}

//cannt assign a value in final variable and parameter...it raise error