class demo
{
  String str;
  final int i=20;
  static final float pi = 3.14f;
  demo(String s)
  {
     str = s;
    // i = 200;
  }

  void show()
  {
     System.out.println("The String is "+str);
  }
}

class Testdemo 
{
  public static void main(String args[])
  {
    final demo d = new demo("MCA");
    demo d1 = new demo("MBA");
    d = d1;
    d = new demo("I changed to MBA");
    d.show();d1.show();
  }
}

//cannt assign a value in final variable and parameter...it raise error