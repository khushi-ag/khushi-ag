//demo of constructor in inheritance

class first
{
  first()
  {
     System.out.println("from class first");
  }
}

class second extends first
{
  second()
  {
     System.out.println("from class second");
  }
}

class TestMain
{
  public static void main(String args[])
  {
     second s = new second();
  }
}