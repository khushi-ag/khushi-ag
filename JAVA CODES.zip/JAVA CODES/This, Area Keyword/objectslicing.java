// concept of Object slicing

class demo
{
  void show_demo()
  {
    System.out.println("Hello from DEMO class");
  }
};

class new_demo extends demo
{
  void show_newDemo()
  {
     System.out.println("Hello from NEW_DEMO class");
  }
}

class objectslicing
{
  public static void main(String args[])
  {
     demo d1 = new demo();
     new_demo nd = new new_demo();
     d1 = nd;
     d1.show_newDemo();
  }
}