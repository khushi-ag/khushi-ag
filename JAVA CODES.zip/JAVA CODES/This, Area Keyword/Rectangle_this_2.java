/*

class Rectangle
{
  int length, width;
  int area()
  {
     return(length*width);
  }
  Rectangle (int length, int width)
  {
     length = length;
     width  = width  ;
 
  } 
  Rectangle(int l)
  {
    this(l,l);
  }    
}

class TestRectangle
{
  public static void main(String args[])
  {
     Rectangle r1 = new Rectangle(5,7);
     System.out.println("The Result is" +r1.area());
     Rectangle r2 = new Rectangle(2);
     System.out.println("The Result is" +r2.area());
     r2=r1;
     System.out.println("The Result is" +r1.area());
     System.out.println("The Result is" +r2.area());  
  }

}

*/

class Rectangle
{
  int length, width;
  int area()
  {
     return(length*width);
  }
  Rectangle (int length, int width)
  {
     this.length = length;
     this.width  = width  ;
 
  } 
  Rectangle(Rectangle obj)
  {
    this(obj.length,obj.width);
  }    
}

class TestRectangle
{
  public static void main(String args[])
  {
     Rectangle r1 = new Rectangle(5,7);
     Rectangle r2 = new Rectangle(r1);
     System.out.println("The length of r1 is" +r1.length);
     System.out.println("The length of r2 is" +r2.length);
     System.out.println("The width of r1 is" +r1.width);
     System.out.println("The width of r2 is" +r2.width);
     System.out.println("The area of r1 is" +r1.area());
     System.out.println("The area of r2 is" +r2.area());
  }

}

