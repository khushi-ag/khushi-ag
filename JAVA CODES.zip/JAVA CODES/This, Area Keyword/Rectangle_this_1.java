class Rectangle
{
  int length, width;
  int area()
  {
     return(length*width);
  }
  Rectangle (int l, int w)
  {
     length = l;
     width  = w;
  } 
  Rectangle(int l)
  {
     this(l,l);
    System.out.println("Hellos");
  }
}

class TestRectangle
{
  public static void main(String args[])
  {
     Rectangle r1 = new Rectangle(5,7);
     System.out.println("The Result is" +r1.area());
     Rectangle r2 = new Rectangle(2);
     System.out.println("The Result is" +r2.area());
     r2=r1;
     System.out.println("After changing the refrence : the areas are ");
     System.out.println("The Result is" +r1.area());
     System.out.println("The Result is" +r2.area());  
  }


}