/*
The abstract class Animal has abstract subclasses named Bird and Reptile.  
Classes Dove, Eagle, Hawk, Penguin and Seagull extend Bird.  
Classes Rattlesnake and Turtle extend Reptile.  
The ColdBlooded interface defines no constants and declares no methods.  
It is implemented by Reptile.  
The OceanDwelling interface also defines no constants and declares no methods.  
It is implemented by the Penguin, Seagull and Turtle classes.  
Define all of these classes and implement the interface as specified.  
Create ONE instance of each class.  
Then display all ColdBooded animals and all OceanDwelling animals.
*/

abstract class Animal
{}

abstract class Bird extends Animal
{}

abstract class Reptile extends Animal implements ColdBlooded
{}

interface ColdBlooded
{}

interface OceanDwelling
{}

class Dove extends Bird
{}

class Eagle extends Bird
{}

class Hawk extends Bird
{}

class Penguin extends Bird implements OceanDwelling
{}

class Seagull extends Bird implements OceanDwelling 
{}

class RattleSnake extends Reptile
{}

class Turtle extends Reptile implements OceanDwelling
{}

class abstractTrail
{
	public static void main(String[] args) 
	{
		//created one instance of each class
		//Animal a[] = {new Dove(), new Eagle(), new Hawk(), new Penguin(), new Seagull(), new Rattlesnake(), new Turtle()}; 

		Animal[] a = new Animal[7];
	    a[ 0 ] = new Dove();
	    a[ 1 ] = new Eagle();
	    a[ 2 ] = new Hawk();
	    a[ 3 ] = new Penguin();
	    a[ 4 ] = new Seagull();
	    a[ 5 ] = new RattleSnake();
	    a[ 6 ] = new Turtle();

		//display all ColdBlooded and OceanDwelling animal
		 for ( Animal ai : a )
		 {
		   if ( ai instanceof ColdBlooded )
		    System.out.println(ai.getClass() + " is ColdBlooded" );
		   if ( ai instanceof OceanDwelling )
		    System.out.println(ai.getClass() + " is OceanDwelling" );
		 }
 	}
}

/*
output:
class Penguin is OceanDwelling
class Seagull is OceanDwelling
class RattleSnake is ColdBlooded
class Turtle is ColdBlooded
class Turtle is OceanDwelling
*/
