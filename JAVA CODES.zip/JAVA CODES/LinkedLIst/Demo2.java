import java.util.*;

class Demo2
{
  public static void main(String args[])
  {
     LinkedList LL1 = new LinkedList();
     
     for(int i=0;i<5;i++)
     {
        LL1.addFirst(new Integer(i+1));
     }
     LinkedList LL2 = new LinkedList(LL1);
  
     //LL1.clear(); //remove all the element
      //LL1.remove(1); //remove element at index 1
     //LL1.removeLast(); //remove last element.
     //LL1.addFirst(4444); //added at first.

     System.out.println("The contents in LL1 are "+LL1); 
     System.out.println("\n"+"The contents in LL2 are "+LL2);

     System.out.println("\n"+"LL2 contians 2 :"+LL2.contains(new Integer(2)));     

     System.out.println("\n"+"Index of 2 is  :"+LL2.indexOf(new Integer(2)));

     LL2.set(4,new Float(99.9999));
     LL2.add(3,new String ("added"));  //add at last

    System.out.println(LL2 );     
  }
}