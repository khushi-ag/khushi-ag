import java.util.*;

class Demo1
{
  public static void main(String args[])
  {
    LinkedList LL = new LinkedList();
    System.out.println("The Size of Linked List is"+LL.size());

    LL.add("B");
    LL.add("c");
    LL.add("D");
    LL.addFirst("A");
    LL.addLast("G");
    LL.add("E");
    LL.add("F");
    LL.addLast("M");
    LL.addLast("A");

    System.out.println("The contents in Linked list are "+LL);

    LL.remove("G");
    LL.removeLast();
    LL.removeFirst();

    System.out.println("The contents in Linked list are "+LL);

    Object val = LL.get(6-1);
    String str = (String)val;
    System.out.println("The value of Str is"+str); 

    System.out.println("The First object is"+LL.getFirst());
   
    System.out.println("The Last object is "+LL.getLast());   

    System.out.println("\n"+"The list is");
    for (int i=0;i<LL.size();i++)
      System.out.println("Element "+i+":"+LL.get(i));
  }

}