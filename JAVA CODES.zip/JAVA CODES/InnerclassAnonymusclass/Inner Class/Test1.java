class OuterClass 
{
   public class NestedClass 
   {
       public void print() 
       {
        System.out.println("Message from nested class"); 
       }
    }
} 

public class Test1 
{
    public static void main(String args[])
   {
       OuterClass oc = new OuterClass();
       OuterClass.NestedClass nc = oc.new NestedClass();
       nc.print();

    }
}

/* it works:
class OuterClass 
{
   public class NestedClass 
   {
       public void print() 
       {
        System.out.println("Message from nested class"); 
       }
    }

    public class Abcd
    {
        public void show() 
       {
        System.out.println("Message from abcd class"); 
       }
    }
} 

public class Test1 
{
    public static void main(String args[])
   {
       OuterClass oc = new OuterClass();
       OuterClass.NestedClass nc = oc.new NestedClass();
       OuterClass.Abcd ac = oc.new Abcd();
       nc.print();
       ac.show();

    }
}

//output:
//Message from nested class
//Message from abcd class

*/