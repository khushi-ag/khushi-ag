class TeststaticOuter1
{  
    static int data=30;  
    static class Inner
    {  
	  void msg()
	  {
		System.out.println("data is "+data);
	  }  
    }  
	public static void main(String args[])
	{  
		TeststaticOuter1.Inner obj=new TeststaticOuter1.Inner();  
		obj.msg();  
	}  
}  