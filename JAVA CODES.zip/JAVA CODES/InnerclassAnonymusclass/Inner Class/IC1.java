public class IC1 
{
    public int x = 10;

    class Inner 
    {
       public int x = 1;
       void m(int x) 
	   {
            System.out.println("x = " + x);
            System.out.println("this.x = " + this.x);
            System.out.println("IC1.this.x = " + IC1.this.x);
        }
    }

    public static void main(String args[]) 
    {
        IC1 t = new IC1();  //outer class obj
        IC1.Inner i = t.new Inner(); // outer.inner new_obj = obj_outer.new inner();
        i.m(5);
    }
}
/*
output:
x = 5
this.x = 1
IC1.this.x = 10
*/
