//Java program to demonstrate Anonymous inner class 

interface Age //interface declare
{ 
     int x = 25; 
    void getAge(); //method declaration
} 

class AnonymousDemo1 
{ 
    public static void main(String[] args) 
   { 
     Age obj1 = new Age() //interface body
	{ 
          public void getAge() //method defination
		{ 
               System.out.print("Age is "+x); 
          } 
     }; 
     obj1.getAge(); //method called
    } 
} 