import java.util.*;

class Demo4
{
  public static void main(String args[])
  {
    ArrayList AL1 = new ArrayList();
    AL1.add(new Integer(1));
    AL1.add(new Integer(2));
    AL1.add(new Integer(3));
    AL1.add(new Integer(4));
    System.out.println("The contents of AL1 are"+AL1);
 
    Object obj[] = AL1.toArray();
    int sum = 0;
    for(int i=0;i<obj.length;i++)
       sum+=((Integer) obj[i]).intValue();
    System.out.println("Sum is ="+sum); // it will get the sum of the no. 1+2+3+4=10

  }



}