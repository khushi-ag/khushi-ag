import java.util.*;

class Demo3
{
  public static void main(String args[])
  {
    ArrayList AL1 = new ArrayList();
    AL1.add(new String("RAM"));
    AL1.add(new Integer(12));
    AL1.add(new Date());
    AL1.add(new Boolean(true));
    AL1.add(new Double(25.45));
    AL1.add(new Character('M'));
    System.out.println("The contents in AL1 are"+AL1.size());
   
    for (int i=0;i<AL1.size();i++)
    {
      System.out.println("Element "+i+":"+AL1.get(i));
    }
   
 }
}