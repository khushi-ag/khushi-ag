import java.util.*;

class Demoooo
{
  public static void main(String args[])
  {
     ArrayList al1 = new ArrayList();
     
     al1.add("Monday");
     al1.add("Tuesday");
     al1.add("Wednesday");
     ArrayList al2 = new ArrayList();
   
     al2.add("rrrrr");
     al2.add(al1);
	   System.out.println("The data inside al1 is");
     System.out.println(al1);
	    System.out.println("The data inside al2 is");
     System.out.println(al2);
     
     
  }
}

//capacity is the size of the array list i.e the number of elements in the ArrayList.