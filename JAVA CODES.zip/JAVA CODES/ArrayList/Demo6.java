import java.util.*;

class Demo6
{
  public static void main(String args[])
  {
    ArrayList al = new ArrayList();
    al.add("MCA");
    al.add("MBA");
    al.add("Mtech");

   ArrayList al1 = new ArrayList();
   al1.add("BCA");
   al1.add("BBA");
   al1.add("Bsc");

   //al.addAll(al1);
  
   Iterator itr = al.iterator();
   while(itr.hasNext())
   {
     System.out.println(itr.next());
   }

  
  /* al.removeAll(al1);
   Iterator itr1 = al.iterator();
   while(itr1.hasNext())
   {
     System.out.println(itr1.next());
   }

   
   System.out.println("Now the output of RetainAll method.....");
   al.retainAll(al1);
   Iterator itr2 = al.iterator();
   while(itr2.hasNext())
   {
     System.out.println(itr2.next());
   }
*/
 
  }
}