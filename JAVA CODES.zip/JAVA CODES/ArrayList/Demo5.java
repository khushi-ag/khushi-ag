import java.util.*;

class Employee
{
  int empno;
  String empName;
  int empAge;
  
  Employee(int empno,String empName,int empAge)
  {
    this.empno = empno;
    this.empName = empName;
    this.empAge = empAge;
  }
}


class Demo5
{
  public static void main(String args[])
  {
    Employee emp1 = new Employee(101,"Rishi",27);
    Employee emp2 = new Employee(102,"meet",24);
    Employee emp3 = new Employee(103,"Abhi",29);

    ArrayList al = new ArrayList();
    al.add(emp1);
    al.add(emp2);
    al.add(emp3);
 
    Iterator itr = al.iterator();
    while(itr.hasNext())
    {
      Employee emp = (Employee)itr.next();
      System.out.println(emp.empno+" "+emp.empName+" "+emp.empAge);
    }
  }
}