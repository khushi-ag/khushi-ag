import java.util.*;

class Demo2
{
  public static void main(String args[])
  {
     ArrayList AL1 = new ArrayList();
     System.out.println("The size of the AL1 is "+AL1.size());
     AL1.add("Jan");
     AL1.add("Feb");
     AL1.add("May");
     AL1.add(2,"March");  // it add at 2nd position, value- march
     AL1.add(3,"April");
     AL1.add("May");
     AL1.add("June");
     System.out.println("The size of the AL1 is "+AL1.size()); 
     System.out.println("The contents available in AL1 are "+AL1);
     AL1.remove(2); 
     System.out.println("The contents available in AL1 are "+AL1);
  }
}
//starts from 0 