import java.util.*;

class Demo 
{
  public static void main(String args[])
  {
     ArrayList al1 = new ArrayList();
     System.out.println("Initial Capacity of al is "+  al1.size());
     al1.add("Monday");
     al1.add("Tuesday");
     al1.add("Wednesday");
     ArrayList al2 = new ArrayList(al1);
     ArrayList al3 = new ArrayList(5);
     System.out.println("The size of AL1 is "+ al1.size());
     
     System.out.println("The Size of AL2 is "+ al2.size());
     
     System.out.println("The Size of AL3 is "+ al3.size()); //0 bcuz 5 define ki h value- 0 h
     
  }
}

//capacity is the size of the array list i.e the number of elements in the ArrayList.