WE CAN DO THIS:::

//What is wrong in the following code?
public class Test 
{
    public static void main(String[] args) 
    {
        Object fruit = new Fruit();
        Object apple = (Apple)fruit;
    }
}

class Apple extends Fruit 
{}

class Fruit 
{}

Wrong: Object apple = (Apple)fruit;
Causes a runtime ClassCastingException.


/* 
public class First_C {  
      public void myMethod()   
    {  
    System.out.println("Method");  
    }  
      
    {  
    System.out.println(" Instance Block");  
    }  
          
    public void First_C()  
    {  
    System.out.println("Constructor ");  
    }  
    static {  
        System.out.println("static block");  
    }  
    public static void main(String[] args) {  
    First_C c = new First_C();  
    c.First_C();  
    c.myMethod();  
  }  
}

output:
static...instance...constructor...method
*/

//qus:2
/*
interface calculate 
{
    void cal(int item);
}
class display implements calculate 
{
    int x;
    public void cal(int item) 
    {
        x = item * item;
    }
}
class interfaces 
{
    public static void main(String args[]) 
    {
        display arr = new display();
        arr.x = 0;
        arr.cal(2);
        System.out.print(arr.x);
    }
}

output
4
*/

// qus:3 it raise an compiletime error
class First_C {
    public static void main(String args[]) {    
        System.out.println(demo());
    }  
    int demo() {
        return 20;
    }  
}
/* output 
First_C.java:62: error: non-static method demo() cannot be referenced from a static context
        System.out.println(demo());
                           ^
1 error
*/

//qus:4 
int arr[] = new int[5];
System.out.println(arr);

//output: garbage value

