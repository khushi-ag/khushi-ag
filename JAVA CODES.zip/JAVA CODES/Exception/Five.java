class Five
{
  public static void main(String args[])
  {
      try
      {
         int arr[] = new int[5];
         arr[5] = 25/0; 
      }
   

      catch(ArithmeticException e)
      {      
         
         System.out.println("Arithmetic Excpetion Occurs.................");
      }
      finally
      {
        System.out.println("Finally block executed");
      }
      System.out.println("Rest of the code will be executed");
      
      
  }
}