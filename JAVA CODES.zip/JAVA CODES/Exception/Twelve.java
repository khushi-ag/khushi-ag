//Case III and IV --> if the super class method declares an Exception


import java.io.*;

class Parent
{
  void msg() throws ArithmeticException
  {
      System.out.println("Parent class called");
  }
}

class Child extends Parent
{
  void msg() throws  Exception
  {
      System.out.println("Child class called");    
  }
  
  public static void main(String args[])
  {
      Parent p = new Child();
      try
      {
          p.msg();
      }
      catch(Exception e)
      {
      }
  }
}