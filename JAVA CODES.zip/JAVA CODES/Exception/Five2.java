class Five2
{
  public static void main(String args[])
  {
      try
      {
         int arr[] = new int[5];
         arr[3] = 25; 
      }
      catch(ArrayIndexOutOfBoundsException e)
      {      
         
         System.out.println("Null Pointer Excpetion Occurs.................");
      }
      /*catch(NullPointerException e)
      {      
         System.out.println("Null Pointer Excpetion Occurs.................");
      }*/
      finally
      {
        System.out.println("Finally block executed");
      }
      System.out.println("Rest of the code will be executed");
      
      
  }
}