class Seven
{
  public static void main(String args[]) throws ArithmeticException
  {
      try
      {
         int arr[] = new int[5];
         arr[5] = 25;
         if(arr[4] <  40)
         {
            throw new ArrayIndexOutOfBoundsException("Here Arrise");       
         } 
     }
      catch(Exception e)
      {
         System.out.println("Exception occurs.........");
      }      
      finally
      {
        System.out.println("Finally block executed");
      }
      System.out.println("Rest of the code will be executed");
      
      
  }
}