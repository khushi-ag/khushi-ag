class MarksException extends Exception
{
  MarksException(String s)
  {
    super(s);
  }
}

class Fourteen
{
  static void check(int mark) throws MarksException
  {
     if (mark < 40)
        throw new MarksException("Congo.. U r Failed"); 
     else
        System.out.println("Welcome in the New Semester");
  }

   public static void main(String args[])
   {
      try{
       check(20);
       }
      catch(Exception e)
      {
         System.out.println("Exception occured"+e);
      }
   System.out.println("Rest of the code to be executed");
 }}