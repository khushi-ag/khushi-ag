class Three
{
  public static void main(String args[])
  {
      try
      {
         int arr[] = new int[5];
         arr[5] = 25; 
      }
      catch(Exception exx)
      {      
         System.out.println("Exception ..................");
      }
      catch(ArrayIndexOutOfBoundsException ex)
      {      
         System.out.println("ArrayIndexOutOfBounds occurs.................");
      }      
      catch(ArithmeticException e)
      {      
         
         System.out.println("Arithmetic Excpetion Occurs.................");
      }
      
      
  }
}