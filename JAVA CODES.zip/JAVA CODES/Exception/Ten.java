import java.io.*;

class Demo
{
  void C()
  {
     //throw new IOException("device Error");
    throw new ArithmeticException("device Error");
  }

  void B()
  {
     C();
  }
  
  void A()
  {
    try
    {
      B();
    }
    catch(Exception e)
    {
      System.out.println(e);
    }
  }  

}

class Ten
{
  public static void main(String args[])
  {
     Demo d = new Demo();
     d.A();
     System.out.println("Rest of the code to be executed.....");   
  }
}