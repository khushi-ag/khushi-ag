import java.io.IOException;

class Demo
{
  void C() throws IOException
  {
     throw new java.io.IOException("device Error");
   //  throw new ArithmeticException("device Error");
  }

  void B() throws IOException
  {
     C();
  }
  
  void A() 
  {
    try
    {
      B();
    }
    catch(ArithmeticException e)
    {
      System.out.println(e);
    }
  }  

}

class Eleven
{
  public static void main(String args[])
  {
     Demo d = new Demo();
     d.A();
     System.out.println("Rest of the code to be executed.....");   
  }
}