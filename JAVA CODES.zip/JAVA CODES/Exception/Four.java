class Four
{
  public static void main(String args[])
  {
   try
   {
      try
      {
         int i = 50/0;
      }
      catch(ArithmeticException e)
      {      
         System.out.println("Arithmatic Exception.................");
      }
      try
      {
         int arr[] = new int[5];
         arr[5] = 4;
      }
      catch(ArrayIndexOutOfBoundsException ex)
      {
         System.out.println("ArrayIndexOutOfBounds Exception.................");         
      } 
   }
   finally
   {
      System.out.println("Finally block Executed.......");
   }
   System.out.println("Rest of the code will be executed.......");
  }
}