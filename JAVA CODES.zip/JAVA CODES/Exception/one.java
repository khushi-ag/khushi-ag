class one
{
  public static void main(String args[])
  {
      int i = 50/0; 
      System.out.println("Rest of the code is Executed.................");
  }
}