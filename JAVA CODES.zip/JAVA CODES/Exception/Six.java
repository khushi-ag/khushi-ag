class Six
{
  public static void main(String args[])
  {
      try
      {
         int arr[] = new int[5];
         arr[4] = 25;
         if(arr[4] <  40)
         {
            throw new ArrayIndexOutOfBoundsException("Here Arrise");       
         } 
      }
      finally
      {
        System.out.println("Finally block executed");
      }
      System.out.println("Rest of the code will be executed");
      
      
  }
}