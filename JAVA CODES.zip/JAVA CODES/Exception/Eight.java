class Eight
{
  public static void main(String args[])
  {
     try
     {
         int a = Integer.parseInt(args[0]);
         int b = Integer.parseInt(args[1]);
         int quot = 0;
         try
         {
            quot = a/b;
            System.out.println(quot);
         }
         catch(ArithmeticException e)
         {
            System.out.println("Divide by zero");
         }
     }
     catch(NumberFormatException e)
     {
        System.out.println("Incorrect argument type");
     }
   }
}