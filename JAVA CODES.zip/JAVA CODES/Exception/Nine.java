class Demo
{
  void C()
  {
     int i = 50/0;
  }

  void B()
  {
     C();
  }
  
  void A()
  {
    try
    {
      B();
    }
    catch(Exception e)
    {
      System.out.println("Exception Occured");
    }
  }  

}

class Nine
{
  public static void main(String args[])
  {
     Demo d = new Demo();
     d.A();
     System.out.println("Rest of the code to be executed.....");   
  }
}