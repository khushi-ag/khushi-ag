abstract class ABC
{
   ABC()
   { 
      System.out.println("from Constructor");
   }
   abstract void run();
   int i = 19;
   
}

class Test extends ABC
{
  int j = 100;
  void run()
  {
    System.out.println("hello");
  }
  void display()
  {
    System.out.println("From method display");}  
  }

class Demo
{
  public static void main(String args[])
  {
      
     ABC t; //abstract class obj.
      t = new Test(); //viz = class 
     t.run();
    // t.display();
    System.out.println(t.i);
    System.out.println(t.j);  //error in this
  }
}

/* output:
1091
Fan
From Display
------------
from Constructor
hello
19

*/