interface ABC
{
  public void run();
}

class Test implements ABC
{
  public void run()
  {
    System.out.println("hello");
  }
  void display()
  {
    System.out.println("Display from Test class");
  }
}
class Demos
{
  public static void main(String args[])
  {
    Test t = new Test();  //class obj
     t.run();
     t.display();
  }
}