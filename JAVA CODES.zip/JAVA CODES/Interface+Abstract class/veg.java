interface Vegetable
{
  void color();
  void wh_grow();
}

class Spinach implements Vegetable
{
  public void color()
  {
    System.out.println("\n Color of Spinach is green");
  } 
  public void wh_grow()
  {
    System.out.println("Spinach grows above the ground");
  }
}

class Potato implements Vegetable
{
  public void color()
  {
    System.out.println("\n Color of Potato is Browny white");
  } 
  public void wh_grow()
  {
    System.out.println("Potato grows under ground");
  }
} 

class Onion implements Vegetable
{
  public void color()
  {
    System.out.println("\n Color of Onion is whitish red");
  } 
  public void wh_grow()
  {
    System.out.println("Onion grows under ground");
  }
} 

class Tomato implements Vegetable 
{
  public void color()
  {
    System.out.println("\n Color of Tomato is red");
  } 
  public void wh_grow()
  {
    System.out.println("Tomato grows above the ground");
  }
}

class veg
{
  public static void main(String args[])
  {
    //interface object
    /* Vegetable ptr[] = new Vegetable[4];  //array define w size.
     ptr[0] = new Spinach();
     ptr[1] = new Potato();
     ptr[2] = new Onion();
     ptr[3] = new Tomato();*/
    
    //ptr[]= array,value in array is class 
    //obj is same name (in array) for all the class but at diff index

     Vegetable ptr[] ={new Spinach(), new Potato(), new Onion(), new Tomato()};
   
     for (int i=0;i<4;i++)
     {
       ptr[i].color();
       ptr[i].wh_grow();
     }
   }
}