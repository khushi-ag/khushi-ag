interface Item
{
  int item_code = 1091;
  String item_name = "Fan";
}

interface Dis
{
  void display();
}

class DemoItem implements Item,Dis
{
  public void display()
  {
    System.out.println("From Display");
  }
  public static void main(String args[])
   {
    Demo d = new Demo();  //class obj
    System.out.println(d.item_code);
    System.out.println(d.item_name);
    d.display();
  }
}