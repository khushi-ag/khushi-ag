interface Item
{
  int item_code = 1091;
  String item_name = "Fan";
}

interface Dis
{
  void display();
}

interface Common extends Item,Dis
{
  void display();
}

class DemoItem2 implements Common
{
  public void display()
  {
    System.out.println("From Display");
  }
  public static void main(String args[])
   {
    Demo d = new Demo();
    System.out.println(d.item_code);
    System.out.println(d.item_name);
    d.display();
  }
}