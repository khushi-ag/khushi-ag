interface ABC
{  
  public void run();
}

class Test implements ABC
{
  public void run()
  {
    System.out.println("hello");
  }
  void display()
  {
    System.out.println("Display from Test class");
  }
}
class Demo_interface
{
  public static void main(String args[])
  {
    ABC t = new Test(); 
     t.run();
     t.display(); //error..of t.display
  }
}